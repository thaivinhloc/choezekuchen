export const HOME = "/";
export const LOGIN = "/login";
export const SIGNUP = "/signup";
export const PROFILE = "/profile";
export const RETREAT = "/retreat";
export const RETREAT_HISTORY = "/retreat-history";
