export const THEME = {
  primaryFont: "Raleway",
  primary: "#0081ff",
  dark: "#363636",
  default: "#636363",
  textSecondary: "#777777",
};
