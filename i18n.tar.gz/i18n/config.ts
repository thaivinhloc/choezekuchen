export const languages = ["en", "vi"];

export const defaultLanguage = "en";

// Locale files under /locales/[lang]/
export const namespaces = ["common", "header", "login", "retreat"];

export const defaultNamespace = "common";
