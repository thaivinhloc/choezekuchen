export default function About({ message }) {
  return <h1>{message}</h1>;
}
