import BoxContainer from "components/BoxContainer";
import React from "react";

const HistoryOfChoezenKuchen = () => {
  return (
    <div>
      <BoxContainer
        type="vertical"
        contentLeft="Image"
        contentRight="Content"
      />
    </div>
  );
};

export default HistoryOfChoezenKuchen;
