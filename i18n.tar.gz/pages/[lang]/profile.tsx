import Profile from "components/Auth/Profile";
import React, { FC } from "react";

const ProfilePage: FC<{}> = () => {
  /* Render */
  return <Profile />;
};

export default ProfilePage;
