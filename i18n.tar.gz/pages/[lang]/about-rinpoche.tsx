import React from "react";

const AboutRinpoche = () => {
  return <div>AboutRinpoche</div>;
};

export default AboutRinpoche;
